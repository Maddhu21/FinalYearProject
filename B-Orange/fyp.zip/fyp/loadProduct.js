//1. Create div
let div = document.createElement('div');

//2. Create a text content
let textNode = document.createTextNode('This is a dynamically generates<br>');
div.appendChild(textNode);

